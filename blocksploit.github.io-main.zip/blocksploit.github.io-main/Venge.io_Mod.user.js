// ==UserScript==
// @name         Venge.io Mod SECOND REWRITE [E]
// @namespace    https://blocksploit.github.io
// @version      0.1
// @description  Developing...
// @author       Blockman_#0431
// @match        *://venge.io/*
// @require      https://unpkg.com/guify@0.12.0/lib/guify.min.js
// @require      http://mrdoob.github.io/stats.js/build/stats.min.js
// @require      https://raw.githubusercontent.com/blocksploit/blocksploit/main/main.js
// @grant        none
// ==/UserScript==